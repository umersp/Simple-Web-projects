const burger = document.querySelector('.burger')
const navbar = document.querySelector('.navbar')
const navlist = document.querySelector('.navlist')

burger.addEventListener('click', ()=>{
    navlist.classList.toggle('v-visi-resp');
    navbar.classList.toggle('h-nav-resp');
})